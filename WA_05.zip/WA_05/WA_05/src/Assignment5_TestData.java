import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
*
*  Be aware that this file might be changed during grading!
*/

public class Assignment5_TestData {
    public final ArrayList<GraphInfo> test_cases;
    public final ArrayList<String> test_descriptions;
    public final ArrayList<Integer> test_start_nodes;
    public final ArrayList<ArrayList<Integer>> expected_dfs_matrix;
    public final ArrayList<ArrayList<Integer>> expected_dfs_lists;
    public final ArrayList<ArrayList<Integer>> expected_bfs_matrix;
    public final ArrayList<ArrayList<Integer>> expected_bfs_lists;

    public Assignment5_TestData(){
        this.test_cases = new ArrayList<>();
        this.test_descriptions = new ArrayList<>();
        this.test_start_nodes = new ArrayList<>();

        this.expected_dfs_matrix = new ArrayList<>();
        this.expected_dfs_lists = new ArrayList<>();
        this.expected_bfs_matrix = new ArrayList<>();
        this.expected_bfs_lists = new ArrayList<>();

        // Case 1: 5 vertices, 1 CC
        ArrayList<EdgeInfo> list_edges = new ArrayList<>();
        list_edges.add(new EdgeInfo(0,1 ));
        list_edges.add(new EdgeInfo(1,2 ));
        list_edges.add(new EdgeInfo(2,3 ));
        list_edges.add(new EdgeInfo(3,4 ));
        list_edges.add(new EdgeInfo(4,0 ));
        GraphInfo test_graph = new GraphInfo(5, list_edges);
        this.test_cases.add(test_graph);
        this.test_descriptions.add("Graph with 5 vertices, 5 edges making a cycle");
        this.test_start_nodes.add(0);
        this.expected_dfs_matrix.add(new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4)));
        this.expected_dfs_lists.add(new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4)));
        this.expected_bfs_matrix.add(new ArrayList<>(Arrays.asList(0, 1, 4, 2, 3)));
        this.expected_bfs_lists.add(new ArrayList<>(Arrays.asList(0, 1, 4, 2, 3)));

        // Case 2: 7 vertices, 2 CC
        list_edges = new ArrayList<>();
        list_edges.add(new EdgeInfo(0,1 ));
        list_edges.add(new EdgeInfo(1,4 ));
        list_edges.add(new EdgeInfo(4,6 ));
        list_edges.add(new EdgeInfo(6,0 ));
        list_edges.add(new EdgeInfo(2,3 ));
        list_edges.add(new EdgeInfo(6,4 ));
        list_edges.add(new EdgeInfo(3,5 ));
        list_edges.add(new EdgeInfo(5,2 ));
        list_edges.add(new EdgeInfo(0,6 ));
        test_graph = new GraphInfo(7, list_edges);
        this.test_cases.add(test_graph);
        this.test_descriptions.add("Graph with 7 vertices, 7 edges making 2 connected components with 4 and 3 nodes each");
        this.test_start_nodes.add(3);
        // this.expected_dfs_matrix.add(new ArrayList<>(List.of(new Integer[]{3, 2, 5})));
        this.expected_dfs_matrix.add(new ArrayList<>(Arrays.asList(3, 2, 5)));
        this.expected_dfs_lists.add(new ArrayList<>(Arrays.asList(3, 2, 5)));
        this.expected_bfs_matrix.add(new ArrayList<>(Arrays.asList(3, 2, 5)));
        this.expected_bfs_lists.add(new ArrayList<>(Arrays.asList(3, 2, 5)));

        // Case 3: 5 vertices, 1 CC
        list_edges = new ArrayList<>();
        list_edges.add(new EdgeInfo(0,1 ));
        list_edges.add(new EdgeInfo(1,4 ));
        list_edges.add(new EdgeInfo(1,4 ));
        list_edges.add(new EdgeInfo(1,4 ));
        list_edges.add(new EdgeInfo(4,3 ));
        list_edges.add(new EdgeInfo(3,4 ));
        list_edges.add(new EdgeInfo(3,0 ));
        list_edges.add(new EdgeInfo(0,2 ));
        list_edges.add(new EdgeInfo(2,1 ));
        list_edges.add(new EdgeInfo(4,2 ));
        list_edges.add(new EdgeInfo(2,0 ));
        list_edges.add(new EdgeInfo(2,3 ));
        test_graph = new GraphInfo(5, list_edges);
        this.test_cases.add(test_graph);
        this.test_descriptions.add("Graph with 5 vertices, 4 cliques of 3 nodes each");
        this.test_start_nodes.add(2);
        this.expected_dfs_matrix.add(new ArrayList<>(Arrays.asList(2, 0, 1, 4, 3)));
        this.expected_dfs_lists.add(new ArrayList<>(Arrays.asList(2, 0, 1, 4, 3)));
        this.expected_bfs_matrix.add(new ArrayList<>(Arrays.asList(2, 0, 1, 3, 4)));
        this.expected_bfs_lists.add(new ArrayList<>(Arrays.asList(2, 0, 1, 4, 3)));

        // Case 4: 8 vertices, 1 CC
        list_edges = new ArrayList<>();
        list_edges.add(new EdgeInfo(0,1 ));
        list_edges.add(new EdgeInfo(0,3 ));
        list_edges.add(new EdgeInfo(0,1 ));
        list_edges.add(new EdgeInfo(0,3 ));
        list_edges.add(new EdgeInfo(2,5 ));
        list_edges.add(new EdgeInfo(2,1 ));
        list_edges.add(new EdgeInfo(2,3 ));
        list_edges.add(new EdgeInfo(2,1 ));
        list_edges.add(new EdgeInfo(4,7 ));
        list_edges.add(new EdgeInfo(6,7 ));
        list_edges.add(new EdgeInfo(4,5 ));
        list_edges.add(new EdgeInfo(2,3 ));
        list_edges.add(new EdgeInfo(2,5 ));
        list_edges.add(new EdgeInfo(4,3 ));
        list_edges.add(new EdgeInfo(6,5 ));
        test_graph = new GraphInfo(8, list_edges);
        this.test_cases.add(test_graph);
        this.test_descriptions.add("Graph with 8 vertices, bipartite");
        this.test_start_nodes.add(4);
        this.expected_dfs_matrix.add(new ArrayList<>(Arrays.asList(4, 3, 0, 1, 2, 5, 6, 7)));
        this.expected_dfs_lists.add(new ArrayList<>(Arrays.asList(4, 7, 6, 5, 2, 1, 0, 3)));
        this.expected_bfs_matrix.add(new ArrayList<>(Arrays.asList(4, 3, 5, 7, 0, 2, 6, 1)));
        this.expected_bfs_lists.add(new ArrayList<>(Arrays.asList(4, 7, 5, 3, 6, 2, 0, 1)));

        // Case 4: 9 vertices, 1 CC
        list_edges = new ArrayList<>();
        list_edges.add(new EdgeInfo(0,3 ));
        list_edges.add(new EdgeInfo(3,6 ));
        list_edges.add(new EdgeInfo(1,4 ));
        list_edges.add(new EdgeInfo(4,7 ));
        list_edges.add(new EdgeInfo(2,5 ));
        list_edges.add(new EdgeInfo(5,8 ));
        list_edges.add(new EdgeInfo(7,4 ));
        list_edges.add(new EdgeInfo(5,2 ));
        list_edges.add(new EdgeInfo(8,5 ));
        list_edges.add(new EdgeInfo(0,1 ));
        list_edges.add(new EdgeInfo(1,2 ));
        list_edges.add(new EdgeInfo(3,4 ));
        list_edges.add(new EdgeInfo(4,3 ));
        list_edges.add(new EdgeInfo(2,1 ));
        list_edges.add(new EdgeInfo(1,0 ));
        list_edges.add(new EdgeInfo(4,5 ));
        list_edges.add(new EdgeInfo(6,7 ));
        list_edges.add(new EdgeInfo(7,8 ));

        test_graph = new GraphInfo(9, list_edges);
        this.test_cases.add(test_graph);
        this.test_descriptions.add("Graph with 9 vertices, regular 2D grid of 3x3");
        this.test_start_nodes.add(0);
        this.expected_dfs_matrix.add(new ArrayList<>(Arrays.asList(0, 1, 2, 5, 4, 3, 6, 7, 8)));
        this.expected_dfs_lists.add(new ArrayList<>(Arrays.asList(0, 3, 6, 7, 4, 1, 2, 5, 8)));
        this.expected_bfs_matrix.add(new ArrayList<>(Arrays.asList(0, 1, 3, 2, 4, 6, 5, 7, 8)));
        this.expected_bfs_lists.add(new ArrayList<>(Arrays.asList(0, 3, 1, 6, 4, 2, 7, 5, 8)));
    }

    public int n_cases(){
        return this.test_cases.size();
    }
}
