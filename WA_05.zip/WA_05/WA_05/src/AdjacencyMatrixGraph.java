import java.util.ArrayList;
import java.util.Iterator;


public class AdjacencyMatrixGraph implements Graph {
    // TODO: YOUR ATTRIBUTES HERE
    private boolean[][] adjacencyMatrix;
    private int vertices;


    public AdjacencyMatrixGraph(int size){
        // TODO: INITIALIZE YOUR ATTRIBUTES HERE
        this.vertices = size;
        adjacencyMatrix = new boolean[vertices][vertices];
    }

    // add an edge v-w
    public void addEdge(int v, int w){
        // TODO: ADD AN EDGE TO THE GRAPH.
        // TODO: HANDLE REPEATED EDGES PROPERLY!
        adjacencyMatrix[v][w] = true;
        adjacencyMatrix[w][v] = true;
    }

    // vertices adjacent to v
    public Iterable<Integer> adj(int v){
        // TODO: your code here

        ArrayList<Integer> adj_to_v = new ArrayList<>();

        for(int i = 0; i < adjacencyMatrix[v].length; i++)
        {
            if(adjacencyMatrix[v][i])
            {
                adj_to_v.add(i);
            }
        }
        return adj_to_v; // TODO: CHANGE THIS
    }

    // number of vertices
    public int V(){
        // TODO: your code here
        return this.vertices; // TODO: CHANGE THIS
    }

    // number of edges
    public int E(){
        // TODO: your code here
        int num_of_edges = 0;

        for(int i = 0; i < adjacencyMatrix.length; i++)
        {
            for(int j = 0; j < adjacencyMatrix[i].length; j++)
            {
                if(adjacencyMatrix[i][j])
                {
                    num_of_edges++;
                }
            }
        }

        return num_of_edges/2; // TODO: CHANGE THIS
    }

}
