import java.util.ArrayList;
import java.util.Iterator;


public class AdjacencyMatrixGraph implements Graph {
    // TODO: YOUR ATTRIBUTES HERE
    private final boolean[][] adjMatrix;
    private final int numVerticies;

    public AdjacencyMatrixGraph(int size){
        // TODO: INITIALIZE YOUR ATTRIBUTES HERE
        this.numVerticies = size;
        this.adjMatrix = new boolean[numVerticies][numVerticies];
    }

    // add an edge v-w
    public void addEdge(int v, int w){
        // TODO: ADD AN EDGE TO THE GRAPH.
        // TODO: HANDLE REPEATED EDGES PROPERLY!
        if(isValidVertex(v) && isValidVertex(w))
        {
            adjMatrix[v][w] = true;

        }

    }

    // vertices adjacent to v
    public Iterable<Integer> adj(int v){
        // TODO: your code here
        ArrayList<Integer> neighbors = new ArrayList<>();

        if(!isValidVertex(v))
        {
            return neighbors;
        }

        for(int i = 0; i < numVerticies; i++)
        {
            if(adjMatrix[v][i])
            {
                neighbors.add(i);
            }
        }

       return neighbors;// TODO: CHANGE THIS
    }

    // number of vertices
    public int V(){
        // TODO: your code here
        return numVerticies * numVerticies; // TODO: CHANGE THIS
    }

    // number of edges
    public int E(){
        // TODO: your code here
        int edges = 0;
        for(int i = 0; i < adjMatrix.length; i++)
        {
            for(int j = 0; j < adjMatrix[i].length; j++)
            {
                if(adjMatrix[i][j])
                {
                    edges++;
                }
            }
        }

        return edges; // TODO: CHANGE THIS
    }

    private boolean isValidVertex(int index)
    {
        return  index >= 0 && index < numVerticies;
    }
}
