/*
 *
 *  Be aware that this file might be changed during grading!
 */

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Assignment5_Test {
    public static void score_tests() {
        Assignment5_TestData test_data = new Assignment5_TestData();

        int t_correct_step_1 = 0;
        int t_correct_step_2 = 0;
        int t_correct_step_3 = 0;
        int t_correct_step_4 = 0;
        int n_cases = test_data.n_cases();
        for (int test_case=0; test_case < n_cases; test_case++) {
            System.out.println("\nRunning Test Case #" + (test_case + 1));

            // THE MAIN ALGORITHM IS HERE
            GraphInfo current_graph_info = test_data.test_cases.get(test_case);
            Graph step_1_out = Assignment5_Main.create_adj_matrix_graph_from_info(current_graph_info);
            Graph step_2_out = Assignment5_Main.create_adj_list_graph_from_info(current_graph_info);

            int start_node = test_data.test_start_nodes.get(test_case);
            ArrayList<Integer> step_3_out_matrix = Assignment5_Main.run_DFS_traversal(step_1_out, start_node);
            ArrayList<Integer> step_3_out_lists = Assignment5_Main.run_DFS_traversal(step_2_out, start_node);

            ArrayList<Integer> step_4_out_matrix = Assignment5_Main.run_BFS_traversal(step_1_out, start_node);
            ArrayList<Integer> step_4_out_lists = Assignment5_Main.run_BFS_traversal(step_2_out, start_node);

            // This is just prints and grading ...
            System.out.println("- Input: " + test_data.test_descriptions.get(test_case));
            System.out.println("  - " + current_graph_info);
            System.out.println("- Step 1: Creating Graph (with Adjacency Matrix)");
            System.out.println("  - Produced Output (# Nodes): " + step_1_out.V());
            System.out.println("  - Produced Output (# Edges): " + step_1_out.E());
            System.out.println("  - Expected Output (# Nodes): " + current_graph_info.num_vertices);
            System.out.println("  - Expected Output (# Edges): " + unique_edges(current_graph_info.edges_to_add).size());
            System.out.println("  - Validating if edges are Identical");
            if (same_edges(step_1_out, current_graph_info)) {
                System.out.println("  --> Correct!");
                t_correct_step_1 += 1;
            } else {
                System.out.println("  --> Incorrect!");
            }

            System.out.println("- Step 2: Creating Graph (with Adjacency Lists)");
            System.out.println("  - Produced Output (# Nodes): " + step_2_out.V());
            System.out.println("  - Produced Output (# Edges): " + step_2_out.E());
            System.out.println("  - Expected Output (# Nodes): " + current_graph_info.num_vertices);
            System.out.println("  - Expected Output (# Edges): " + unique_edges(current_graph_info.edges_to_add).size());
            System.out.println("  - Validating if edges are Identical");
            if (same_edges(step_2_out, current_graph_info)) {
                System.out.println("  --> Correct!");
                t_correct_step_2 += 1;
            } else {
                System.out.println("  --> Incorrect!");
            }

            System.out.println("- Step 3: Running DFS");
            System.out.println("  - Starting Node: " +  start_node);
            System.out.println("  - Produced Output (Sequence) for Adjacency Matrix Graph: " + step_3_out_matrix);
            System.out.println("  - Produced Output (Sequence) for Adjacency Lists Graph: " + step_3_out_lists);
            System.out.println("  - Expected Output (Sequence) for Adjacency Matrix Graph: " + test_data.expected_dfs_matrix.get(test_case));
            System.out.println("  - Expected Output (Sequence) for Adjacency Lists Graph: " + test_data.expected_dfs_lists.get(test_case));
            if (step_3_out_matrix.equals(test_data.expected_dfs_matrix.get(test_case)) &&
                step_3_out_lists.equals(test_data.expected_dfs_lists.get(test_case))) {
                System.out.println("  --> Correct!");
                t_correct_step_3 += 1;
            } else {
                System.out.println("  --> Incorrect!");
            }

            System.out.println("- Step 4: Running BFS");
            System.out.println("  - Starting Node: " +  start_node);
            System.out.println("  - Produced Output (Sequence) for Adjacency Matrix Graph: " + step_4_out_matrix);
            System.out.println("  - Produced Output (Sequence) for Adjacency Lists Graph: " + step_4_out_lists);
            System.out.println("  - Expected Output (Sequence) for Adjacency Matrix Graph: " + test_data.expected_bfs_matrix.get(test_case));
            System.out.println("  - Expected Output (Sequence) for Adjacency Lists Graph: " + test_data.expected_bfs_lists.get(test_case));
            if (step_4_out_matrix.equals(test_data.expected_bfs_matrix.get(test_case)) &&
                    step_4_out_lists.equals(test_data.expected_bfs_lists.get(test_case))) {
                System.out.println("  --> Correct!");
                t_correct_step_4 += 1;
            } else {
                System.out.println("  --> Incorrect!");
            }
        }

        System.out.println("\n\nSummary");
        System.out.println("- Step 1 correct: " + t_correct_step_1 + " / " + n_cases);
        System.out.println("- Step 2 correct: " + t_correct_step_2 + " / " + n_cases);
        System.out.println("- Step 3 correct: " + t_correct_step_3 + " / " + n_cases);
        System.out.println("- Step 4 correct: " + t_correct_step_4 + " / " + n_cases);
    }

    private static boolean same_edges(Graph graph, GraphInfo source){
        Set<String> unique_on_source = unique_edges(source.edges_to_add);

        if (graph.V() != source.num_vertices){
            return false;
        }

        if (graph.E() != unique_on_source.size()){
            return false;
        }

        ArrayList<EdgeInfo> graph_edges = new ArrayList<>();
        for (int v = 0; v < source.num_vertices; v++){
            for (Integer w : graph.adj(v)){
                // add edge ...
                graph_edges.add(new EdgeInfo(v, w));
            }
        }


        Set<String> unique_on_graph = unique_edges(graph_edges);

        return unique_on_source.equals(unique_on_graph);
    }

    private static Set<String> unique_edges(ArrayList<EdgeInfo> all_edges){
        Set<String> tempo_set = new HashSet<>();
        for (EdgeInfo e : all_edges){
            // add the edge to the set ... using a normalized representation
            // where the smaller index is always first
            // the set will take care of repetitions
            if (e.v <= e.w){
                tempo_set.add(e.v + "-" + e.w);
            } else {
                tempo_set.add(e.w + "-" + e.v);
            }
        }

        return tempo_set;
    }
}
