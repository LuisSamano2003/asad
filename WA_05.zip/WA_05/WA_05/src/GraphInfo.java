import java.util.ArrayList;

/*
 *
 *    DO NOT MODIFY!!!
 */

public class GraphInfo {
    public final int num_vertices;
    public final ArrayList<EdgeInfo> edges_to_add;

    public GraphInfo(int num_vertices, ArrayList<EdgeInfo> edges){
        this.num_vertices = num_vertices;
        this.edges_to_add = edges;
    }

    public String toString(){
        StringBuilder builder = new StringBuilder("[GraphInfo: V=[0 .. ");
        builder.append(this.num_vertices);
        builder.append("], Raw Edges=[");
        for (int i = 0; i < this.edges_to_add.size(); i++){
            if (i > 0){
                builder.append(", ");
            }
            builder.append(this.edges_to_add.get(i).toString());
        }
        builder.append("]");
        return builder.toString();
    }
}
