/*
 *    DO NOT MODIFY!!!
 */

public class EdgeInfo {
    public final int v;
    public final int w;

    public EdgeInfo(int v, int w){
        this.v = v;
        this.w = w;
    }

    public String toString(){
        return "(" + this.v + " <--> " + this.w + ")";
    }
}
