import java.util.ArrayList;



public class Assignment5_Main {
    /*
     *  Step 1:
     *     This function takes a GraphInfo object and creates a Graph based on Adjacency Matrices.
     *     The GraphInfo object contains all the required information about the graph including the number of vertices
     *     and edges that the new Graph object should have. BE AWARE THAT THIS LIST MIGHT INCLUDE DUPLICATED EDGES!
     *
     *     This is a very straight-forward function. The code is actually given to you, and you must NOT change this
     *     code. Instead, your goal is to implement the constructor and addEdge function of the AdjacencyMatrixGraph
     *     class to make this function work as intended. To pass all tests, you must also implement correctly other
     *     functions E(), V() and adj() of the same class.
     *
     *  Output:
     *     An AdjacencyMatrixGraph which has all vertices and edges in GraphInfo data
     *
     *  Hints:
     *     - You need to implement all functions of the AdjacencyMatrixGraph class.
     * */
    public static AdjacencyMatrixGraph create_adj_matrix_graph_from_info(GraphInfo data){
        // DO NOT MODIFY!
        AdjacencyMatrixGraph graph = new AdjacencyMatrixGraph(data.num_vertices);

        for (EdgeInfo e : data.edges_to_add){
            graph.addEdge(e.v, e.w);
        }

        return graph;
    }

    /*
     *  Step 2:
     *     This function takes a GraphInfo object and creates a Graph based on Lists of Adjacency.
     *     The GraphInfo object contains all the required information about the graph including the number of vertices
     *     and edges that the new Graph object should have. BE AWARE THAT THIS LIST MIGHT INCLUDE DUPLICATED EDGES!
     *
     *     This is a very straight-forward function. The code is actually given to you, and you must NOT change this
     *     code. Instead, your goal is to implement the constructor and addEdge function of the AdjacencyListGraph
     *     class to make this function work as intended. To pass all tests, you must also implement correctly other
     *     functions E(), V() and adj() of the same class.
     *
     *  Output:
     *     An AdjacencyListGraph which has all vertices and edges in GraphInfo data
     *
     *  Hints:
     *     - You need to implement all functions of the AdjacencyListGraph class.
     * */
    public static AdjacencyListGraph create_adj_list_graph_from_info(GraphInfo data){
        // DO NOT MODIFY!
        AdjacencyListGraph graph = new AdjacencyListGraph(data.num_vertices);

        for (EdgeInfo e : data.edges_to_add){
            graph.addEdge(e.v, e.w);
        }

        return graph;
    }

    /*
     *  Step 3:
     *     This function takes a Graph object (either based on Adjacency Matrices or Lists), and runs a Depth First
     *     Search (DFS) traversal starting from the specified node. It then returns the list of nodes that were visited
     *     in pre-order.
     *
     *     This is a very straight-forward function. The code is actually given to you, and you must NOT change this
     *     code. Instead, your goal is to implement the depth_first_search function of the GraphTraversal class to make
     *     this function work as intended. Tests are aware that Matrices of Adjacency sort connections by vertex index,
     *     while Lists of Adjacency are sensitive to the order in which edges are added.
     *
     *  Output:
     *     An ArrayList<Integer> which has all vertices that were visited in pre-order DFS.
     *
     *  Hints:
     *     - You need to implement depth_first_search of the GraphTraversal class.
     * */
    public static ArrayList<Integer> run_DFS_traversal(Graph graph, int v){
        // DO NOT MODIFY!
        GraphTraversal gt = new GraphTraversal(graph, v, GraphTraversal.TraversalDFS);
        return gt.getResults();
    }

    /*
     *  Step 4:
     *     This function takes a Graph object (either based on Adjacency Matrices or Lists), and runs a Breadth First
     *     Search (BFS) traversal starting from the specified node. It then returns the list of nodes that were visited.
     *
     *     This is a very straight-forward function. The code is actually given to you, and you must NOT change this
     *     code. Instead, your goal is to implement the breadth_first_search function of the GraphTraversal class to
     *     make this function work as intended. Tests are aware that Matrices of Adjacency sort connections by vertex
     *     index, while Lists of Adjacency are sensitive to the order in which edges are added.
     *
     *  Output:
     *     An ArrayList<Integer> which has all vertices that were visited in BFS.
     *
     *  Hints:
     *     - You need to implement breadth_first_search of the GraphTraversal class.
     * */
    public static ArrayList<Integer> run_BFS_traversal(Graph graph, int v){
        // DO NOT MODIFY!
        GraphTraversal gt = new GraphTraversal(graph, v, GraphTraversal.TraversalBFS);
        return gt.getResults();
    }

    public static void main(String[] args) {
        // Keep this line here!
        Assignment5_Test.score_tests();

        // STEP 5: Feedback
        System.out.println("[Feedback: What did you think about this assignment?]");
    }
}
