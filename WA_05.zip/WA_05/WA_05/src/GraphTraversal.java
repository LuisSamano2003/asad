import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Queue;
import java.util.ArrayDeque;


public class GraphTraversal {
    // GIVEN TO YOU, DO NOT MODIFY THE ATTRIBUTES!!!
    public static final int TraversalDFS = 0;
    public static final int TraversalBFS = 1;

    // GIVEN TO YOU, DO NOT MODIFY THE ATTRIBUTES!!!
    private Graph graph;
    private ArrayList<Integer> results;
    private boolean[] marked;
    private int[] edgeTo;

    public GraphTraversal(Graph graph, int v, int type){
        // GIVEN TO YOU, DO NOT MODIFY THE CONSTRUCTOR!!!
        this.graph = graph;
        this.marked = new boolean[Math.max(graph.V(), 0)];
        this.edgeTo = new int[Math.max(graph.V(), 0)];
        for (int i = 0; i < this.edgeTo.length; i++){
            edgeTo[i] = -1;
        }
        this.results = new ArrayList<>();

        if (type == TraversalDFS){
            depth_first_search(v);
        } else {
            breadth_first_search(v);
        }
    }

    private void depth_first_search(int current){
        // TODO: your logic for DFS HERE
        // TODO: DO NOT FORGET TO ADD CURRENT NODE TO LIST OF RESULTS IN PRE-ORDER
        marked[current] = true;
        results.add(current);
        for(int w : graph.adj(current))
        {
            if(!marked[w])
            {
                depth_first_search(w);
                edgeTo[w] = current;
            }
        }
    }

    private void breadth_first_search(int current){
        // TODO: your logic for BFS HERE
        Queue<Integer> queue = new ArrayDeque<>();
        marked[current] = true;
        queue.add(current);

        while(!queue.isEmpty())
        {
            int vertex = queue.remove();
            results.add(vertex);

            for(int neighbor : graph.adj(vertex))
            {
                if(!marked[neighbor]){
                    marked[neighbor] = true;
                    edgeTo[neighbor] = vertex;
                    queue.add(neighbor);
                }
            }

        }

    }

    public ArrayList<Integer> getResults(){
        // return a copy of the object ...
        return new ArrayList<>(this.results);
    }

}
