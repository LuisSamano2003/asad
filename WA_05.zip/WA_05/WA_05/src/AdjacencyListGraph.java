import org.w3c.dom.Node;

import java.util.ArrayList;
import java.util.LinkedList;


public class AdjacencyListGraph implements Graph {
    // TODO: YOUR ATTRIBUTES HERE
    private int size;
    private ArrayList<LinkedList<Integer>> list_graph;

    public AdjacencyListGraph(int size){
        // TODO: INITIALIZE YOUR ATTRIBUTES HERE
        this.size = size;
        this.list_graph = new ArrayList<>();

        for (int i = 0; i < size; i++) {
            list_graph.add(new LinkedList<>());
        }
    }

    public void addEdge(int v, int w) {
        // TODO: ADD AN EDGE TO THE GRAPH.
        // TODO: DO NOT ALLOW REPEATED EDGES!
        if(list_graph.get(v).contains(w))
        {
            return;
        }
        list_graph.get(v).add(w);
        list_graph.get(w).add(v);
    }

    public Iterable<Integer> adj(int v) {
        // TODO: your code here
        LinkedList<Integer> adj_to_v = list_graph.get(v);

        return adj_to_v; // TODO: CHANGE THIS
    }

    public int V() {
        // TODO: your code here
        return size; // TODO: CHANGE THIS
    }

    public int E() {
        // TODO: your code here

        int edgeEntries = 0;

        for (LinkedList<Integer> neighbors : list_graph) {
            edgeEntries += neighbors.size();
        }

        return edgeEntries / 2; // TODO: CHANGE THIS
    }
}
