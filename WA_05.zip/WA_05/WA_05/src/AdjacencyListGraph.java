import java.util.ArrayList;



public class AdjacencyListGraph implements Graph {
    // TODO: YOUR ATTRIBUTES HERE

    public AdjacencyListGraph(int size){
        // TODO: INITIALIZE YOUR ATTRIBUTES HERE
    }

    public void addEdge(int v, int w) {
        // TODO: ADD AN EDGE TO THE GRAPH.
        // TODO: DO NOT ALLOW REPEATED EDGES!

    }

    public Iterable<Integer> adj(int v) {
        // TODO: your code here
        return null; // TODO: CHANGE THIS
    }

    public int V() {
        // TODO: your code here
        return -1; // TODO: CHANGE THIS
    }

    public int E() {
        // TODO: your code here
        return -1; // TODO: CHANGE THIS
    }
}
