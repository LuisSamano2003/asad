import java.util.ArrayList;


public class Digraph {
    private int count_edges;
    private ArrayList<Integer>[] adjacencies;

    public Digraph(int size){
        this.adjacencies = (ArrayList<Integer>[]) new ArrayList[size];
        for (int i = 0; i < size; i++){
            this.adjacencies[i] = new ArrayList<>();
        }
        this.count_edges = 0;
    }

    public void addEdge(int v, int w) {
        if (v < 0 || v >= this.adjacencies.length){
            throw new RuntimeException("addEdge: Value v=" + v + " is out of the expected range [0, " + this.V() + "]");
        }
        if (w < 0 || w >= this.adjacencies.length){
            throw new RuntimeException("addEdge: Value w=" + w + " is out of the expected range [0, " + this.V() + "]");
        }

        if (v == w){
            // Do not add loop edges ...
            return;
        }

        // Check if the edge already exists ...
        for (Integer other : this.adjacencies[v]){
            if (other == w){
                // already exists ... do not add ...
                return;
            }
        }

        // If it gets here, the edge is new, add it to the end ...
        this.adjacencies[v].add(w);
        this.count_edges++;
    }

    public Iterable<Integer> adj(int v) {
        return this.adjacencies[v];
    }

    public int V() {
        return this.adjacencies.length;
    }

    public int E() {
        return this.count_edges;
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder("[Digraph: ");
        result.append("Vertices=" + this.V());
        result.append(", Edges={");
        int count_e = 0;
        for (int v = 0; v < this.adjacencies.length; v++){
            for (int w: this.adjacencies[v]){
                if (count_e > 0){
                    result.append(", ");
                }
                result.append(v);
                result.append("->");
                result.append(w);
                count_e += 1;
            }
        }
        result.append("}]");
        return result.toString();
    }
}
