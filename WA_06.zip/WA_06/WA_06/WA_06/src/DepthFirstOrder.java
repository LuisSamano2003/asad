import java.util.*;


public class DepthFirstOrder {
    // TODO: your attributes here  ...
    private final boolean[] marked;
    private final ArrayList<Integer> post;

    public DepthFirstOrder(Digraph G, int start_vertex)
    {
        // TODO: your logic here ...
        marked = new boolean[G.V()];
        post = new ArrayList<>();
        depth_first_search(G, start_vertex);
    }

    public DepthFirstOrder(Digraph G){
        marked = new boolean[G.V()];
        post = new ArrayList<>();

        for (int v = 0; v < G.V(); v++) {
            if (!marked[v]) {
                depth_first_search(G, v);
            }
        }
    }

    private void depth_first_search(Digraph G, int v)
    {
        // TODO: your logic here ...
        marked[v] = true;

        for(int neighbor : G.adj(v))
        {
            if(!marked[neighbor]){
                depth_first_search(G, neighbor);
            }
        }

        post.add(v);
    }
    public Iterable<Integer> reversePostorder()
    {
        // TODO: your logic here ...

        ArrayList<Integer> finalResult = new ArrayList<>(post);
        Collections.reverse(finalResult);

        return finalResult;
    }
}
