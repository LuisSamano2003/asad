import java.util.ArrayList;

/*
 *    DO NOT MODIFY!!!
 */

public class Course {
    public final String code;
    public final String name;
    public final ArrayList<String> prerequisites;

    public Course(String course_code, String course_name, ArrayList<String> prerequisites){
        this.code = course_code;
        this.name = course_name;
        this.prerequisites = new ArrayList<>(prerequisites);
    }

    public String toString(){
        StringBuilder tempo = new StringBuilder("{");
        tempo.append(this.code);
        tempo.append(": ");
        tempo.append(this.name);
        tempo.append("; Req: ");
        tempo.append(this.prerequisites);
        tempo.append("}");

        return tempo.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj.getClass() != this.getClass()){
            return false;
        }

        Course other = (Course)obj;
        return this.name.equals(other.name) && this.code.equals(other.code) && this.prerequisites.equals(other.prerequisites);
    }
}
