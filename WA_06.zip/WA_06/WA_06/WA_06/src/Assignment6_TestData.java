import java.util.ArrayList;
import java.util.Arrays;

/*
 *
 *  Be aware that this file might be changed during grading!
 */

public class Assignment6_TestData {
    private final ArrayList<String> all_course_str_list;
    private final ArrayList<Course> all_course_obj_list;
    public final ArrayList<String> all_codes_to_check;
    public final ArrayList<String> expected_digraph_str;
    public final ArrayList<String> expected_topological_str;
    public final ArrayList<String> expected_requirements_str;

    public final ArrayList<ArrayList<Integer>> test_cases;

    public Assignment6_TestData() {
        this.test_cases = new ArrayList<>();
        this.all_course_str_list = new ArrayList<>();
        this.all_course_obj_list = new ArrayList<>();
        this.all_codes_to_check = new ArrayList<>();
        this.expected_digraph_str = new ArrayList<>();
        this.expected_topological_str = new ArrayList<>();
        this.expected_requirements_str = new ArrayList<>();
        //0-4
        this.all_course_str_list.add("CSC 402: Data Structures I; Prerequisites: CSC 401.");
        ArrayList<String> prereq = new ArrayList<>(Arrays.asList("CSC 401"));
        Course tempo = new Course("CSC 402", "Data Structures I", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("CSC 403: Data Structures II; Prerequisites: CSC 402.");
        prereq = new ArrayList<>(Arrays.asList("CSC 402"));
        tempo = new Course("CSC 403", "Data Structures II", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("CSC 400: Discrete Structures for Computer Science; Prerequisites: None.");
        prereq = new ArrayList<>();
        tempo = new Course("CSC 400", "Discrete Structures for Computer Science", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("CSC 421: Applied Algorithms and Structures; Prerequisites: CSC 400, CSC 403.");
        prereq = new ArrayList<>(Arrays.asList("CSC 400", "CSC 403"));
        tempo = new Course("CSC 421", "Applied Algorithms and Structures", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("CSC 401: Introduction to Programming; Prerequisites: None.");
        prereq = new ArrayList<>();
        tempo = new Course("CSC 401", "Introduction to Programming", prereq);
        this.all_course_obj_list.add(tempo);

        //5-7
        this.all_course_str_list.add("CSC 435: Distributed Systems I; Prerequisites: CSC 403, CSC 407.");
        prereq = new ArrayList<>(Arrays.asList("CSC 403", "CSC 407"));
        tempo = new Course("CSC 435", "Distributed Systems I", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("CSC 406: Systems I; Prerequisites: CSC 401.");
        prereq = new ArrayList<>(Arrays.asList("CSC 401"));
        tempo = new Course("CSC 406", "Systems I", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("CSC 407: Systems II; Prerequisites: CSC 406, CSC 402.");
        prereq = new ArrayList<>(Arrays.asList("CSC 406", "CSC 402"));
        tempo = new Course("CSC 407", "Systems II", prereq);
        this.all_course_obj_list.add(tempo);

        //8-10
        this.all_course_str_list.add("CSC 447: Concepts of Programming Languages; Prerequisites: CSC 403, CSC 406.");
        prereq = new ArrayList<>(Arrays.asList("CSC 403", "CSC 406"));
        tempo = new Course("CSC 447", "Concepts of Programming Languages", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("CSC 453: Principles of Database Management Systems; Prerequisites: CSC 403.");
        prereq = new ArrayList<>(Arrays.asList("CSC 403"));
        tempo = new Course("CSC 453", "Principles of Database Management Systems", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("SE 456: Architecture of Real-Time Systems; Prerequisites: CSC 403.");
        prereq = new ArrayList<>(Arrays.asList("CSC 403"));
        tempo = new Course("SE 456", "Architecture of Real-Time Systems", prereq);
        this.all_course_obj_list.add(tempo);

        // 11-14
        this.all_course_str_list.add("CSC 580: Artificial Intelligence II; Prerequisites: CSC 578.");
        prereq = new ArrayList<>(Arrays.asList("CSC 578"));
        tempo = new Course("CSC 580", "Artificial Intelligence II", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("CSC 412: Tools and Techniques for Computational Analysis; Prerequisites: None.");
        prereq = new ArrayList<>();
        tempo = new Course("CSC 412", "Tools and Techniques for Computational Analysis", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("CSC 578: Neural Networks and Deep Learning; Prerequisites: CSC 412, CSC 480.");
        prereq = new ArrayList<>(Arrays.asList("CSC 412", "CSC 480"));
        tempo = new Course("CSC 578", "Neural Networks and Deep Learning", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("CSC 480: Artificial Intelligence I; Prerequisites: CSC 403.");
        prereq = new ArrayList<>(Arrays.asList("CSC 403"));
        tempo = new Course("CSC 480", "Artificial Intelligence I", prereq);
        this.all_course_obj_list.add(tempo);



        // 15-18
        this.all_course_str_list.add("CSC 577: Recommender Systems; Prerequisites: CSC 412, DSC 478.");
        prereq = new ArrayList<>(Arrays.asList("CSC 412", "DSC 478"));
        tempo = new Course("CSC 577", "Recommender Systems", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("CSC 528: Computer Vision; Prerequisites: CSC 481.");
        prereq = new ArrayList<>(Arrays.asList("CSC 481"));
        tempo = new Course("CSC 528", "Computer Vision", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("DSC 478: Programming Machine Learning Applications; Prerequisites: CSC 480.");
        prereq = new ArrayList<>(Arrays.asList("CSC 480"));
        tempo = new Course("DSC 478", "Programming Machine Learning Applications", prereq);
        this.all_course_obj_list.add(tempo);

        this.all_course_str_list.add("CSC 481: Introduction to Image Processing; Prerequisites: CSC 412.");
        prereq = new ArrayList<>(Arrays.asList("CSC 412"));
        tempo = new Course("CSC 481", "Introduction to Image Processing", prereq);
        this.all_course_obj_list.add(tempo);

        // Case 1: Small graph with 5 vertices
        test_cases.add(new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4)));
        expected_digraph_str.add("[Digraph: Vertices=5, Edges={0->4, 1->0, 3->2, 3->1}]");
        expected_topological_str.add("[CSC 401, CSC 402, CSC 403, CSC 400, CSC 421]");
        all_codes_to_check.add("CSC 421");
        expected_requirements_str.add("[CSC 400, CSC 401, CSC 402, CSC 403]");

        // Case 2: Small graph with 8 vertices
        test_cases.add(new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7)));
        expected_digraph_str.add("[Digraph: Vertices=8, Edges={0->4, 1->0, 3->2, 3->1, 5->1, 5->7, 6->4, 7->6, 7->0}]");
        expected_topological_str.add("[CSC 401, CSC 402, CSC 403, CSC 400, CSC 421, CSC 406, CSC 407, CSC 435]");
        all_codes_to_check.add("CSC 435");
        expected_requirements_str.add("[CSC 401, CSC 402, CSC 403, CSC 406, CSC 407]");

        // Case 3: Small graph with 11 vertices
        test_cases.add(new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10)));
        expected_digraph_str.add("[Digraph: Vertices=11, Edges={0->4, 1->0, 3->2, 3->1, 5->1, 5->7, 6->4, 7->6, 7->0, 8->1, 8->6, 9->1, 10->1}]");
        expected_topological_str.add("[CSC 401, CSC 402, CSC 403, CSC 400, CSC 421, CSC 406, CSC 407, CSC 435, CSC 447, CSC 453, SE 456]");
        all_codes_to_check.add("CSC 447");
        expected_requirements_str.add("[CSC 401, CSC 402, CSC 403, CSC 406]");

        // Case 4: Medium graph with 15 vertices
        test_cases.add(new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14)));
        expected_digraph_str.add("[Digraph: Vertices=15, Edges={0->4, 1->0, 3->2, 3->1, 5->1, 5->7, 6->4, 7->6, 7->0, 8->1, 8->6, 9->1, 10->1, 11->13, 13->12, 13->14, 14->1}]");
        expected_topological_str.add("[CSC 401, CSC 402, CSC 403, CSC 400, CSC 421, CSC 406, CSC 407, CSC 435, CSC 447, CSC 453, SE 456, CSC 412, CSC 480, CSC 578, CSC 580]");
        all_codes_to_check.add("CSC 580");
        expected_requirements_str.add("[CSC 412, CSC 401, CSC 402, CSC 403, CSC 480, CSC 578]");

        // Case 5: Medium graph with 15 vertices
        test_cases.add(new ArrayList<>(Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18)));
        expected_digraph_str.add("[Digraph: Vertices=19, Edges={0->4, 1->0, 3->2, 3->1, 5->1, 5->7, 6->4, 7->6, 7->0, 8->1, 8->6, 9->1, 10->1, 11->13, 13->12, 13->14, 14->1, 15->12, 15->17, 16->18, 17->14, 18->12}]");
        expected_topological_str.add("[CSC 401, CSC 402, CSC 403, CSC 400, CSC 421, CSC 406, CSC 407, CSC 435, CSC 447, CSC 453, SE 456, CSC 412, CSC 480, CSC 578, CSC 580, DSC 478, CSC 577, CSC 481, CSC 528]");
        all_codes_to_check.add("CSC 528");
        expected_requirements_str.add("[CSC 412, CSC 481]");
    }

    public int n_cases(){
        return this.test_cases.size();
    }

    public ArrayList<String> get_test_case_course_str_list(int test_case){
        ArrayList<String> class_list = new ArrayList<>();
        for (int idx: this.test_cases.get(test_case)){
            class_list.add(this.all_course_str_list.get(idx));
        }

        return class_list;
    }

    public ArrayList<Course> get_test_case_course_obj_list(int test_case){
        ArrayList<Course> class_list = new ArrayList<>();
        for (int idx: this.test_cases.get(test_case)){
            class_list.add(this.all_course_obj_list.get(idx));
        }

        return class_list;
    }
}
