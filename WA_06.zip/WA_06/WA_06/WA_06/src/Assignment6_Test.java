import java.util.ArrayList;

/*
 *
 *    DO NOT MODIFY!!!
 *    BEWARE THAT THIS FILE MIGHT BE CHANGED FOR GRADING
 */

public class Assignment6_Test {
    public static void score_tests() {
        Assignment6_TestData test_data = new Assignment6_TestData();

        int t_correct_step_1 = 0;
        int t_correct_step_2 = 0;
        int t_correct_step_3 = 0;
        int t_correct_step_4 = 0;
        int n_cases = test_data.n_cases();

        for (int test_case = 0; test_case < n_cases; test_case++) {
            System.out.println("\nRunning Test Case #" + (test_case + 1));

            // get current subset of courses:
            ArrayList<String> class_str_list = test_data.get_test_case_course_str_list(test_case);
            ArrayList<Course> class_obj_list = test_data.get_test_case_course_obj_list(test_case);

            // Step 1: Convert List of strings into list of courses
            ArrayList<Course> step_1_out = Assignment6_Main.courses_from_strings(class_str_list);

            // Step 2: convert list of course info into directed graph
            Digraph step_2_out = Assignment6_Main.create_digraph_from_courses(step_1_out);

            // Step 3: Topological sorting of courses
            ArrayList<String> step_3_out = Assignment6_Main.generate_course_sequence(step_1_out, step_2_out);

            // Step 4: Given a course to take, find all requirements
            String check_course = test_data.all_codes_to_check.get(test_case);
            ArrayList<String> step_4_out = Assignment6_Main.find_all_requirements(step_1_out, check_course, step_2_out);

            System.out.println("- Step 1: Creating Course List from Strings");
            System.out.println("  - Input: " + class_str_list);
            System.out.println("  - Produced Output (Courses): " + step_1_out);
            System.out.println("  - Expected Output (Courses): " + class_obj_list);
            if (class_obj_list.equals(step_1_out)){
                System.out.println("  --> Correct!");
                t_correct_step_1 += 1;
            } else {
                System.out.println("  --> Incorrect!");
            }

            System.out.println("- Step 2: Creating Graph from Course List");
            System.out.println("  - Produced Output (Graph): " + step_2_out);
            System.out.println("  - Expected Output (Graph): " + test_data.expected_digraph_str.get(test_case));
            if (step_2_out.toString().equals(test_data.expected_digraph_str.get(test_case))){
                System.out.println("  --> Correct!");
                t_correct_step_2 += 1;
            } else {
                System.out.println("  --> Incorrect!");
            }

            StringBuilder str_builder = new StringBuilder("[");
            int course_count = 0;
            for (Course course: class_obj_list){
                if (course_count > 0) {
                    str_builder.append(", ");
                }
                str_builder.append(course.code);
                course_count += 1;
            }
            str_builder.append("]");
            System.out.println("- Step 3: Creating Topological Order");
            System.out.println("  - Expected Initial Order: " + str_builder);
            System.out.println("  - Produced Output (List): " + step_3_out);
            System.out.println("  - Expected Output (List): " + test_data.expected_topological_str.get(test_case));
            if (step_3_out.toString().equals(test_data.expected_topological_str.get(test_case))){
                System.out.println("  --> Correct!");
                t_correct_step_3 += 1;
            } else {
                System.out.println("  --> Incorrect!");
            }

            System.out.println("- Step 4: Checking all course requirements");
            System.out.println("  - Course to Check: " + check_course);
            System.out.println("  - Produced Output (List): " + step_4_out);
            System.out.println("  - Expected Output (List): " + test_data.expected_requirements_str.get(test_case));
            if (step_4_out.toString().equals(test_data.expected_requirements_str.get(test_case))){
                System.out.println("  --> Correct!");
                t_correct_step_4 += 1;
            } else {
                System.out.println("  --> Incorrect!");
            }
        }

        System.out.println("\n\nSummary");
        System.out.println("- Step 1 correct: " + t_correct_step_1 + " / " + n_cases);
        System.out.println("- Step 2 correct: " + t_correct_step_2 + " / " + n_cases);
        System.out.println("- Step 3 correct: " + t_correct_step_3 + " / " + n_cases);
        System.out.println("- Step 4 correct: " + t_correct_step_4 + " / " + n_cases);
    }
}
