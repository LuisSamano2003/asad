

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Assignment6_Main {
    /*
    *  Step 1:
    *     This function takes a list of strings representing courses, parses them and returns a
    *     list of courses.
    *
    *     Each string follows this format:
    *
    *         “[COURSE CODE]: [COURSE NAME]; Prerequisites: [CODE PREREQUISITE 1], [CODE PREREQUISITE 2], …, [CODE PREREQUISITE N].”
    *
    *     For example:
    *         “CSC 403: Data Structures II; Prerequisites: CSC 402.”
    *
    *     If a course has no prerequisites, it will simply include the word "None" as follows:
    *
    *         “CSC 400: Discrete Structures for Computer Science; Prerequisites: None.”
    *
    *  Output:
    *     - List of courses (ArrayList<Course>)
    * */
    public static ArrayList<Course> courses_from_strings(ArrayList<String> course_info){
        // TODO: your logic here ...
        ArrayList<Course> courseList = new ArrayList<>();
        for(String current_course : course_info)
        {
            String courseName = "";
            String course_code = "";
            ArrayList<String> prereq = new ArrayList<>();

            String[] split_sections = current_course.split("[:;,.]+");

            for(int i = 0; i < split_sections.length; i++)
            {
                //NOTE: It works fine but when there are no prereq, the prereq array list is supposed to say none instead of just an empty thing
                if(i == 0)
                {
                    course_code = split_sections[i];
                    System.out.println("CODE: " + course_code);
                } else if(i == 1)
                {
                    courseName = split_sections[i].trim();
                    System.out.println("NAME: " + courseName);
                } else if(i == 2)
                {
                    continue;
                } else
                {
                    prereq.add(split_sections[i].trim());
                }

            }
                Course current = new Course(course_code, courseName, prereq);
                courseList.add(current);
        }
        return courseList;
    }

    /*
    *  Auxiliary Function:
    *      This function takes as input the list of courses and returns a HashMap where
    *      the keys are the course codes and the values are integers representing the index
    *      or position of the key in the list of courses. The hashmap can be used to
    *       map course codes to their corresponding graph vertex indices.
    *
    *  Results:
    *       A HashMap<String, Integer> where
    *           Key is String representing Course Code
    *           Value is  Integer representing associated vertex index
    * */
    public static HashMap<String, Integer> get_mapping(ArrayList<Course> all_courses){
        // TODO: your logic here ...
        return new HashMap<>();
    }

    /*
    *  Step 2:
    *      Create a directed graph from the given list of courses, where
    *       - Each vertex represents a course in the list (follows the same order)
    *       - Each edge links a course to one of its direct prerequisites
    *
    *  Output:
    *       A Digraph object that includes all required connections
    *
    *  HINT:
    *       The auxiliary function get_mapping can be used here to make this function
    *       efficient, and your job easier.
     */
    public static Digraph create_digraph_from_courses(ArrayList<Course> all_courses){
        // TODO: your logic here ...
        return new Digraph(all_courses.size());
    }

    /*
    * Step 3:
    *      Compute a valid scheduling for all courses. This scheduling must respect which courses
    *      can be taken first, and which one should be taken later. This is the reverse post order
    *      of the depth first search.
    *
    * Output:
    *    - A list of strings (course codes) in the order in which they can be taken (a valid schedule).
    *
    * HINT:
    *    - You MUST implement (and use) the DepthFirstOrder class here.
    * */
    public static ArrayList<String> generate_course_sequence(ArrayList<Course> all_courses, Digraph req_graph){
        // TODO: your logic here ...
        return new ArrayList<>();
    }

    /*
    * Step 4:
    *      First, determine all extended prerequisites for a given course. That is, follow its
    *      requirements, and the requirements of its requirements, recursively until all required courses
    *      have been covered. Then, this function should return a list of strings (course codes) representing
    *      a valid schedule for these courses. This is the reverse post order of the depth first search
    *      starting from the given course.
    *
    * Output:
     *    - A list of strings (course codes) in the order in which they can be taken (a valid schedule).
    *
    * HINT:
    *    - The auxiliary function get_mapping can be used here.
    *    - You MUST implement (and use) the DepthFirstOrder class here.
    *    - A small change is needed in the constructor of the DepthFirstOrder class to generate the answer
    * */
    public static ArrayList<String> find_all_requirements(ArrayList<Course> all_courses, String course_name, Digraph req_graph){
        // TODO: your logic here ...
        return new ArrayList<>();
    }

    public static void main(String[] args) {
        // Keep this line here!
        Assignment6_Test.score_tests();

        // STEP 5: Feedback
        System.out.println("[Feedback: What did you think about this assignment?]");
    }
}
