import java.util.Stack;



public class DepthFirstOrder {
    // TODO: your attributes here  ...

    public DepthFirstOrder(Digraph G, int start_vertex)
    {
        // TODO: your logic here ...
    }

    private void depth_first_search(Digraph G, int v)
    {
        // TODO: your logic here ...
    }
    public Iterable<Integer> reversePostorder()
    {
        // TODO: your logic here ...
        return null;
    }
}
