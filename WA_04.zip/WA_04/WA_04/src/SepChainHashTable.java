import java.util.ArrayList;
import java.util.Collections;

/*
 *  CREATED BY: Kenny Mauricio Davila Castellanos
 *       FOR : DATA STRUCTURES II
 *   DO NOT REDISTRIBUTE!
 *
 *  MODIFIED BY: [YOUR NAME HERE!]
 * */

public class SepChainHashTable<Key, Value> {
    // <START: DO NOT MODIFY>
    private int m;
    private int n;
    private final boolean resizable;
    private SequentialSearchChain<Key, Value>[] symbol_table;

    public SepChainHashTable(){
        this(16, false);
    }

    public SepChainHashTable(int m, boolean resizable){
        this.n = 0;
        this.m = m;
        this.resizable = resizable;
        this.symbol_table = (SequentialSearchChain<Key, Value>[]) new SequentialSearchChain[m];
        for (int i = 0; i < this.m; i++){
            this.symbol_table[i] = new SequentialSearchChain<>();
        }
    }

    public int getSize(){
        return this.n;
    }

    public int getChainCount(){
        return this.symbol_table.length;
    }

    public boolean isResizable(){
        return this.resizable;
    }

    public void print_chain_statistics(){
        ArrayList<Integer> lengths = new ArrayList<>();

        // first, get the lengths of all chains
        int total_sum = 0;
        for (int i = 0; i < this.symbol_table.length; i++){
            int local_count = this.symbol_table[i].count_nodes();
            total_sum += local_count;
            lengths.add(local_count);
        }

        Collections.sort(lengths);
        double median_length;
        if (lengths.size() % 2 == 1){
            median_length = lengths.get(lengths.size() / 2);
        } else {
            median_length = (lengths.get((lengths.size() / 2) - 1) + lengths.get((lengths.size() / 2))) / 2.0;
        }

        System.out.println("  -> Hash Table Statistics:");
        System.out.println("    - Unique Keys: " + total_sum);
        System.out.println("    - Number of Chains: " + this.symbol_table.length);
        System.out.format("    - Average Chain Length: %.2f%n", total_sum / (float)this.symbol_table.length);
        System.out.format("    - Minimum Chain Length: %d%n", lengths.get(0));
        System.out.format("    - Maximum Chain Length: %d%n", lengths.get(lengths.size() - 1));
        System.out.format("    - Median Chain Length: %.2f%n", median_length);

        // System.out.println(lengths);
    }

    // <END: DO NOT MODIFY>

    // -----------------------
    // YOUR CHANGES START HERE

    /*
    * HASH function. Takes as input a Key and computes the hash (position in the symbol table array)
    * */
    private int hash(Key key){
        // TODO: use book and/or slides to implement this simply function correctly
        return (key.hashCode() & 0x7fffffff) % this.m;
    }

    /*
    * The PUT method of the Hash Table
    *
    * HINT: You must implement the Hash method first to use it here
    * HINT: This requires that you implement the put method of the SequentialSearchChain.
    * */
    public void put(Key key, Value value){
        // TODO: your code for put in here

        // This part is GIVEN to YOU. DO NOT MODIFY THIS PART
        if (this.resizable && this.n / m >= 8){
            this.resize(this.m * 2);
        }
    }

    /*
     * The RESIZE method of the Hash Table
     *
     *  This function takes a new size, and it will re-generate the table at the given size. Note that this size could
     *  be bigger, smaller, or even the same as current size.
     *
     *  ALL existing keys must be re-hashed to add them on the new symbol table
     *
     *  HINT: Hash function requires m, and this function changes the value of m.
     *        Do it in the right order to get the right results.
     * */
    private void resize(int size){
        // TODO: YOU CANNOT DIRECTLY CREATE GENERIC ARRAYS IN JAVA
        // TODO: INSTEAD ... USE THE SAME TRICK I USED IN THE CONSTRUCTOR
        // SequentialSearchChain<Key, Value>[] resized_table = (SequentialSearchChain<Key, Value>[]) new SequentialSearchChain[size];
    }

    /*
     * The GET method of the Hash Table
     *
     * HINT: You must implement the Hash method first to use it here
     * HINT: This requires that you implement the get method of the SequentialSearchChain class
     * */
    public Value get(Key key){
        // TODO: your code here
        int i = hash(key);


        return null;
    }


    /*
     * The getKeys() method.
     *
     * This method runs an iterable object (e.g. an ArrayList) with all Keys currently stored on this Hash Table.
     *
     * HINT: This requires implementing the getKeys() method of the SequentialSearchChain class.
     * */
    public Iterable<Key> getKeys() {
        // TODO: Your logic here.
        return new ArrayList<Key>();
    }
}
