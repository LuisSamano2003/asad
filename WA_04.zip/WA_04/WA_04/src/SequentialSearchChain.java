import java.util.ArrayList;

/*
 *  CREATED BY: Kenny Mauricio Davila Castellanos
 *       FOR : DATA STRUCTURES II
 *   DO NOT REDISTRIBUTE!
 *
 *  MODIFIED BY: [YOUR NAME HERE!]
 * */

public class SequentialSearchChain<Key, Value> {
    // <START: DO NOT MODIFY>
    private ChainNode<Key, Value> first;

    public SequentialSearchChain(){
        this.first = null;
    }

    public ChainNode<Key, Value> getFirst(){
        return this.first;
    }


    public int count_nodes(){
        if (this.first == null){
            return 0;
        } else {
            return this.first.count_nodes();
        }
    }

    // <END: DO NOT MODIFY>

    // -----------------------
    // YOUR CHANGES START HERE

    /*
     * The PUT method of the Sequential Search Chain.
     *
     * If the key is already on the chain, then this method must simply override current value.
     * If the key is not on the chain, then this method should add it at the beginning of the chain
     *
     * Output:
     *    It must return TRUE if a new node was added to the chain, and FALSE otherwise.
     *
     * - HINT: We discussed this function in class, and it's on the slides ...
     * - HINT: This is NOT identical to the slides. This version returns a boolean.
     * */
    public boolean put(Key key, Value value){
        // TODO: your logic here

        // TODO: It must return TRUE if a new node was added to the chain, and FALSE otherwise.
        return false;
    }

    /*
     * The GET method of the Sequential Search Chain.
     *
     * This method runs the sequential search on the Chain
     *
     * Output:
     *      If the key is found, it returns the corresponding value.
     *      If the key is not on the chain, then this method returns null
     * */
    public Value get(Key key){
        // TODO: your logic here ...
        return null;
    }

    /*
     * The getKeys() method of the Sequential Search Chain.
     *
     * This method runs an iterable object (e.g. an ArrayList) with all Keys currently stored on this chain
     *
     * */
    public Iterable<Key> getKeys(){
        // TODO: your logic here ...
        return new ArrayList<Key>();
    }

}
