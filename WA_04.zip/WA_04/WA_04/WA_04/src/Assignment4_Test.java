import java.util.ArrayList;
import java.util.Arrays;

/*
 *  CREATED BY: Kenny Mauricio Davila Castellanos
 *       FOR : DATA STRUCTURES II
 *   DO NOT REDISTRIBUTE!
 *
 *  DO NOT MODIFY!
 */

public class Assignment4_Test {
    public static void score_tests() {
        Assignment4_TestData test_data = new Assignment4_TestData();

        if (test_data.preloaded_data[0].isEmpty()){
            System.out.println("Error: The CSV files are missing or you did not open the project properly. ");
            System.out.println("       The program could not locate the tests files in the <working directory>");
            return;
        }


        int t_correct_step_1 = 0;
        int t_correct_step_2 = 0;
        int t_correct_step_3 = 0;
        int t_correct_step_4 = 0;
        int n_cases = test_data.n_cases();
        for (int test_case=0; test_case < n_cases; test_case++) {
            System.out.println("\nRunning Test Case #" + (test_case + 1));

            // THE MAIN ALGORITHM IS HERE
            // step 1 ...
            ArrayList<CourseGrade> current_grades = test_data.preloaded_data[test_case];
            int small_max = Math.min(500, current_grades.size());
            ArrayList<CourseGrade> small_test = new ArrayList<CourseGrade>(current_grades.subList(0, small_max));
            long start_time_1 = System.nanoTime();
            SepChainHashTable<String, CourseGrade> step_1_out = Assignment4_Main.index_grades_no_resizing(small_test);
            long end_time_1 = System.nanoTime();
            // step 2 ...
            long start_time_2 = System.nanoTime();
            SepChainHashTable<String, CourseGrade> step_2_out = Assignment4_Main.index_grades_with_resizing(current_grades);
            long end_time_2 = System.nanoTime();
            // step 3 ...
            long start_time_3 = System.nanoTime();
            double[] step_3_out = Assignment4_Main.query_exam_grades(step_2_out, test_data.search_keys[test_case]);
            long end_time_3 = System.nanoTime();
            // Step 4 ...
            long start_time_4 = System.nanoTime();
            SepChainHashTable<String, Integer> step_4_out = Assignment4_Main.count_per_grade(step_2_out,
                    test_data.valid_letter_grades);
            long end_time_4 = System.nanoTime();


            // This is just prints and grading ...
            System.out.println("- Input: " + test_data.inputs[test_case]);
            System.out.println("- Step 1: Generating the Hash-Table index (first 500 only, NO RESIZE)");
            System.out.format("  -> Indexing Time (s): %.6f%n", (end_time_1 - start_time_1) / 1_000_000_000.0 );
            step_1_out.print_chain_statistics();
            System.out.println("  - Produced Output (# Nodes): " + step_1_out.getSize());
            System.out.println("  - Expected Output (# Nodes): " + test_data.expected_step1_sizes[test_case]);
            if (step_1_out.getSize() == test_data.expected_step1_sizes[test_case]) {
                System.out.println("  --> Correct!");
                t_correct_step_1 += 1;
            } else {
                System.out.println("  --> Incorrect!");
            }

            System.out.println("- Step 2: Generating the Hash-Table index (ALL records, MUST RESIZE)");
            System.out.format("  -> Indexing Time (s): %.6f%n", (end_time_2 - start_time_2) / 1_000_000_000.0 );
            step_2_out.print_chain_statistics();
            System.out.println("  - Produced Output (# Nodes): " + step_2_out.getSize());
            System.out.println("  - Produced Output (# Chains): " + step_2_out.getChainCount());
            System.out.println("  - Expected Output (# Nodes): " + test_data.expected_step2_sizes[test_case]);
            System.out.println("  - Expected Output (# Chains): " + test_data.expected_step2_chains[test_case]);
            if ((step_2_out.getSize() == test_data.expected_step2_sizes[test_case]) &&
                (step_2_out.getChainCount() == test_data.expected_step2_chains[test_case])) {
                System.out.println("  --> Correct!");
                t_correct_step_2 += 1;
            } else {
                System.out.println("  --> Incorrect!");
            }

            System.out.println("- Step 3: Querying Exam Grades (On full Index!)");
            System.out.format("  -> Search Time (s): %.6f%n", (end_time_3 - start_time_3) / 1_000_000_000.0 );
            System.out.println("  - Produced Output (# Nodes): " + Arrays.toString(step_3_out));
            System.out.println("  - Expected Output (# Nodes): " + Arrays.toString(test_data.expected_search_results[test_case]));
            if (approx_equal_double_arrays(step_3_out, test_data.expected_search_results[test_case], 0.001)) {
                System.out.println("  --> Correct!");
                t_correct_step_3 += 1;
            } else {
                System.out.println("  --> Incorrect!");
            }

            System.out.println("- Step 4: Letter Grade Distribution (On full Index!)");
            System.out.format("  -> Processing Time (s): %.6f%n", (end_time_4 - start_time_4) / 1_000_000_000.0 );
            System.out.println("  - Produced Output (Count A's): " + step_4_out.get("A"));
            System.out.println("  - Produced Output (Count B's): " + step_4_out.get("B"));
            System.out.println("  - Produced Output (Count C's): " + step_4_out.get("C"));
            System.out.println("  - Produced Output (Count D's): " + step_4_out.get("D"));
            System.out.println("  - Produced Output (Count F's): " + step_4_out.get("F"));
            System.out.println("  - Produced Output (Count W's): " + step_4_out.get("W"));
            System.out.println("  - Produced Expected (Count A's): " + test_data.expected_step4_A[test_case]);
            System.out.println("  - Produced Expected (Count B's): " + test_data.expected_step4_B[test_case]);
            System.out.println("  - Produced Expected (Count C's): " + test_data.expected_step4_C[test_case]);
            System.out.println("  - Produced Expected (Count D's): " + test_data.expected_step4_D[test_case]);
            System.out.println("  - Produced Expected (Count F's): " + test_data.expected_step4_F[test_case]);
            System.out.println("  - Produced Expected (Count W's): " + test_data.expected_step4_W[test_case]);
            if (correct_value(step_4_out, "A", test_data.expected_step4_A[test_case]) &&
                correct_value(step_4_out, "B", test_data.expected_step4_B[test_case]) &&
                correct_value(step_4_out, "C", test_data.expected_step4_C[test_case]) &&
                correct_value(step_4_out, "D", test_data.expected_step4_D[test_case]) &&
                correct_value(step_4_out, "F", test_data.expected_step4_F[test_case]) &&
                correct_value(step_4_out, "W", test_data.expected_step4_W[test_case])){
                System.out.println("  --> Correct!");
                t_correct_step_4 += 1;
            } else {
                System.out.println("  --> Incorrect!");
            }

        }

        System.out.println("\n\nSummary");
        System.out.println("- Step 1 correct: " + t_correct_step_1 + " / " + n_cases);
        System.out.println("- Step 2 correct: " + t_correct_step_2 + " / " + n_cases);
        System.out.println("- Step 3 correct: " + t_correct_step_3 + " / " + n_cases);
        System.out.println("- Step 4 correct: " + t_correct_step_4 + " / " + n_cases);
    }

    private static boolean approx_equal_double_arrays(double[] x, double[] y, double epsilon){
        if (x.length != y.length){
            return false;
        } else {
            for (int i = 0; i < x.length; i++){
                if (x[i] < y[i] - epsilon || y[i] + epsilon < x[i]){
                    return false;
                }
            }
            return true;
        }
    }

    private static boolean correct_value(SepChainHashTable<String, Integer> index, String key, int expected_value){
        Integer value = index.get(key);
        if (value == null){
            return false;
        } else {
            return value == expected_value;
        }
    }
}
