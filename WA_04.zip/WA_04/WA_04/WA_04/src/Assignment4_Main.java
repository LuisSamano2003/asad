import java.util.ArrayList;


public class Assignment4_Main {
    /*
    *  Step 1:
    *     This function takes a list of CourseGrade objects, and creates a Separate Chaining Hash Table
    *     (SepChainHashTable) using the CourseGrade Keys (Term ID + Course ID + Student ID) as the key for the index
    *     and the CourseGrade object as the value. The SepChainHashTable returned here will have a FIXED of 10 bins
    *     and MUST NOT be resizable!
    *
    *     This is a very straight-forward function. The code is actually given to you, and you must NOT change this
    *     code. Instead, your goal is to implement the PUT function of SepChainHashTable to make this function work
    *     as intended
    *
    *  Output:
    *     A HashTable (SepChainHashTable<String, CourseGrade>) which has all CourseGrades indexed by their unique key
    *
    *  Hints:
    *     - You need to implement the "put" and "hash" of the SepChainHashTable class.
    *     - You will also need to implement multiple functions of SequentialSearchChain class
    * */
    public static SepChainHashTable<String, CourseGrade> index_grades_no_resizing(ArrayList<CourseGrade> student_grades){
        // DO NOT CHANGE THIS. THIS INDICATES THAT YOUR HASH TABLE HERE MUST HAVE 10 BINS, AND MUST NOT BE RESIZABLE
        SepChainHashTable<String, CourseGrade> index = new SepChainHashTable<>(10, false);

        for (CourseGrade grade: student_grades){
            String key = grade.getKey();
            // TODO: your goal is to implement this function inside of SepChainHashTable.java
            // TODO: In turn, this will require that you implement other methods of the SequentialSearchChain class
            index.put(key, grade);
        }

        return index;
    }

    /*
     *  Step 2:
     *     This function takes a list of CourseGrade objects, and creates a Separate Chaining Hash Table
     *     (SepChainHashTable) using the CourseGrade Keys (Term ID + Course ID + Student ID) as the key for the index
     *     and the CourseGrade object as the value. The SepChainHashTable returned here will have a VARIABLE SIZE, it
     *     will start with just 2 bins, and will use the rule N / M >= 8 to expand!
     *
     *     This is a very straight-forward function. The code is actually given to you, and you must NOT change this
     *     code. Instead, your goal is to implement the PUT function of SepChainHashTable to make this function work
     *     as intended
     *
     *  Output:
     *     A HashTable (SepChainHashTable<String, CourseGrade>) which has all CourseGrades indexed by their unique key
     * */
    public static SepChainHashTable<String, CourseGrade> index_grades_with_resizing(ArrayList<CourseGrade> student_grades){
        // DO NOT CHANGE THIS. THIS INDICATES THAT YOUR HASH TABLE HERE WILL START WITH 2 BINS,
        // AND MUST GRADUALLY RESIZE ITSELF EVERY TIME THAT ENOUGH KEYS ARE INSERTED
        SepChainHashTable<String, CourseGrade> index = new SepChainHashTable<>(2, true);

        for (CourseGrade grade: student_grades){
            String key = grade.getKey();
            // TODO: your goal is to implement the "resize" function inside of SepChainHashTable.java.
            //       Note that the resize function must be called from within the "put" function every time that the
            //       number of unique keys (n) divided by (m) goes over the threshold (N / M >= 8)
            index.put(key, grade);
        }

        return index;
    }

    /*
    * Step 3:
    *    This function gets a SepChainHashTable index of Course Grades indexed by their unique key, and an array of
    *    Grade keys, and returns an array with the exam scores for each of the given grade_ids. It is possible that
    *    some grade_ids are invalid (e.g., they do NOT exist on the index), and in those cases, the index should return
    *    a null value. If the grade_id is valid, then the function should return the EXAM score for the corresponding
    *    CourseGrade. Otherwise, it should return a -1.0 for that id.
    *
    * Output:
    *    An array of double values corresponding to the EXAM scores for each of the given grade_ids. If the id is
    *    invalid, the corresponding value for the invalid must be -1.0
    *
    * HINT:
    *    - This function requires that you implement the method "get" of the SepChainHashTable class
    *    - The size of the grade_ids array and the double array to return should be identical.
    *    - index must return null for invalid keys. Handle these cases properly to avoid a null pointer exception.
    * */
    public static double[] query_exam_grades(SepChainHashTable<String, CourseGrade> index, String[] grade_ids){
        // TODO: your logic here
        // TODO: DO NOT forget to implement "get" of the SepChainHashTable class. DONE
        // TODO: DO NOT forget to implement "get" of the SequentialSearchChain class. DONE

        /*
            1) Go through ID's
                2) Get the hash to find index for hash table
                    3) Get the sequential chain
                        4) Look through the chain to find the grade
                            5) If found, add to the double method that has the exam scores
        * */
        double[] exam_grades = new double[grade_ids.length];

        for(int i = 0; i < grade_ids.length; i++)
        {
            CourseGrade grade = index.get(grade_ids[i]);

            if(grade == null){
                exam_grades[i] = -1.0;
            } else {
                exam_grades[i] = grade.getExamsScore();
            }
        }

        return exam_grades;
    }

    /*
    * Step 4:
    *    This function takes as input an index of course grades (SepChainHashTable), and an array of valid letter grades
    *    (String[]), and it must return a Hash Table (SepChainHashTable) with the TOTAL COUNT of CourseGrades objects
    *    for each unique valid letter grade.
    *
    *    For example,
    *      if the index only has three grades: 2 of them are A's and the other one is a C,
    *         and the array of valid_letter_grades has the values {"A", "B", "C", "D"},
    *      then this function should return a SepChainHashTable with the following key-value pairs:
    *         [(key: "A", value: 2), (key: "B", value: 0), (key: "C", value: 1), (key: "D", value: 0)]
    *
    *    HINTS:
    *      - This function requires that you implement the getKeys() method of SepChainHashTable.
    *      - You will be using two Hash tables in this function. Both have Keys of String types,
    *        but they represent very different things
    *      - This function requires that you use the "put" and "get" methods of SepChainHashTable
    * */
    public static SepChainHashTable<String, Integer> count_per_grade(SepChainHashTable<String, CourseGrade> index,
                                                                     String[] valid_letter_grades){
        // TODO: your logic here
        // TODO: this function requires implementing and using the getKeys() method of SepChainHashTable

            SepChainHashTable<String, Integer> counts = new SepChainHashTable<>();
            for (String grade : valid_letter_grades) {
                counts.put(grade, 0);
            }

            for (String key : index.getKeys()) {
                CourseGrade courseGrade = index.get(key);
                if (courseGrade != null) {
                    String letterGrade = courseGrade.getLetterGrade();
                    Integer count = counts.get(letterGrade);

                    if (count != null) {
                        counts.put(letterGrade, count + 1);
                    }
                }
            }

            return counts;
    }


    public static void main(String[] args) {
        // Keep this line here!
        Assignment4_Test.score_tests();

        // STEP 5: Feedback
        System.out.println("[Feedback: What did you think about this assignment?]");
    }
}
