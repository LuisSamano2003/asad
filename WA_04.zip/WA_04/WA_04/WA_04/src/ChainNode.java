/*
 *  CREATED BY: Kenny Mauricio Davila Castellanos
 *       FOR : DATA STRUCTURES II
 *   DO NOT REDISTRIBUTE!
 *
 *  DO NOT MODIFY!
 */

public class ChainNode<Key, Value> {
    public final Key key;
    public Value value;

    private ChainNode<Key, Value> next;

    public ChainNode(Key key, Value value, ChainNode<Key, Value> next){
        this.key = key;
        this.value = value;
        this.next = next;
    }

    public ChainNode<Key, Value> getNext(){
        return this.next;
    }

    public int count_nodes(){
        if (this.next == null){
            return 1;
        } else {
            return 1 + this.next.count_nodes();
        }
    }
}
