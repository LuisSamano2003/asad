
/*
 *  CREATED BY: Kenny Mauricio Davila Castellanos
 *       FOR : DATA STRUCTURES II
 *   DO NOT REDISTRIBUTE!
 *
 *  DO NOT MODIFY!
 */

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class Assignment4_TestData {
    public final String[] inputs;
    public final ArrayList<CourseGrade>[] preloaded_data;
    public final String[] valid_letter_grades;
    public final int[] expected_step1_sizes;
    public final int[] expected_step2_sizes;
    public final int[] expected_step2_chains;
    public final String[][] search_keys;
    public final double[][] expected_search_results;
    public final int[] expected_step4_A;
    public final int[] expected_step4_B;
    public final int[] expected_step4_C;
    public final int[] expected_step4_D;
    public final int[] expected_step4_F;
    public final int[] expected_step4_W;

    public Assignment4_TestData() {
        this.inputs = new String[]{
                "test1.csv", "test2.csv", "test3.csv", "test4.csv", "test5.csv"
        };
        this.preloaded_data = new ArrayList[]{
            LoadTestDataFromFile(this.inputs[0]),
            LoadTestDataFromFile(this.inputs[1]),
            LoadTestDataFromFile(this.inputs[2]),
            LoadTestDataFromFile(this.inputs[3]),
            LoadTestDataFromFile(this.inputs[4])
        };

        this.expected_step1_sizes = new int[]{ 10, 100, 500, 500, 500};
        this.expected_step2_sizes = new int[]{ 10, 100, 1000, 10000, 100000};
        this.expected_step2_chains = new int[]{2, 16, 128, 2048, 16384};

        this.search_keys = new String[][] {
            new String[]{"2018-19-04-Summer-HHH475-571741367", "[INVALID_KEY_1]", "1993-94-03-Spring-JJJ316-169010583", "[INVALID_KEY_2]", "2021-22-03-Spring-JJJ038-221923988"},
            new String[]{"[INVALID_KEY_1]", "1987-88-03-Spring-HHH497-168646183", "2018-19-01-Fall-III451-191531673", "1995-96-01-Fall-BBB446-159141099"},
            new String[]{"2022-23-02-Winter-CCC048-412046734", "1988-89-02-Winter-CCC186-578726366", "[INVALID_KEY_1]", "1997-98-01-Fall-GGG346-239649508"},
            new String[]{"1997-98-04-Summer-AAA492-589433312", "2005-06-04-Summer-DDD056-190432041", "1998-99-01-Fall-HHH138-149534777", "[INVALID_KEY_1]"},
            new String[]{"2007-08-03-Spring-AAA123-180727904", "[INVALID_KEY_1]", "2007-08-01-Fall-FFF143-370635773", "2003-04-02-Winter-CCC177-120239511", "[INVALID_KEY_2]", "[INVALID_KEY_3]"}
        };

        this.expected_search_results = new double[][]{
            new double[]{39.95, -1.0, 40.05, -1.0, 16.58},
            new double[]{-1.0, 57.18, 75.98, 27.96},
            new double[]{5.07, 36.2, -1.0, 0.2},
            new double[]{50.88, 1.5, 31.55, -1.0},
            new double[]{27.83, -1.0, 25.2, 19.34, -1.0, -1.0},
        };

        this.valid_letter_grades = new String[]{"A", "B", "C", "D", "F", "W"};
        this.expected_step4_A = new int[]{3, 9, 101, 1002, 10146};
        this.expected_step4_B = new int[]{1, 23, 261, 2500, 24967};
        this.expected_step4_C = new int[]{3, 20, 193, 2023, 19979};
        this.expected_step4_D = new int[]{2, 32, 242, 2514, 24880};
        this.expected_step4_F = new int[]{1, 5, 102, 969, 9893};
        this.expected_step4_W = new int[]{0, 11, 101, 992, 10135};
    }

    private ArrayList<CourseGrade> LoadTestDataFromFile(String filename) {
        ArrayList<CourseGrade> data = new ArrayList<>();

        File in_file = new File(filename);
        try {
            Scanner reader = new Scanner(in_file);

            while (reader.hasNextLine()) {
                String str_mailpackage = reader.nextLine();
                String[] parts = str_mailpackage.split(",");
                //2018-19-01-Fall,GGG133,501440887,23.24,38.86, 62.10, D
                String term_id = parts[0];
                String course_id = parts[1];
                String student_id = parts[2];
                double others_score = Double.parseDouble(parts[3]);
                double exams_score = Double.parseDouble(parts[4]);
                double total_score = Double.parseDouble(parts[5]);
                String letter_grade = parts[6];

                CourseGrade grade = new CourseGrade(term_id, course_id, student_id, exams_score, others_score,
                        total_score, letter_grade);
                data.add(grade);
            }
        } catch (Exception e) {
            System.out.println("Invalid file name");
        }

        System.out.println("A total of " + data.size() + " records were successfully loaded from " + filename);
        return data;
    }

    public int n_cases(){
        return this.inputs.length;
    }
}
