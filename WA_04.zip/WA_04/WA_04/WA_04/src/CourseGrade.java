/*
 *  CREATED BY: Kenny Mauricio Davila Castellanos
 *       FOR : DATA STRUCTURES II
 *   DO NOT REDISTRIBUTE!
 *
 *  DO NOT MODIFY!
 */

public class CourseGrade {
    // Attributes that make the key are immutable
    public final String term_id;
    public final String course_id;
    public final String student_id;
    // Other attributes might be changed
    private double exams_score;
    private double others_score;
    private double total_score;
    private String letter_grade;

    public CourseGrade(String term_id, String course_id, String student_id, double exams_score, double others_score,
                       double total_score, String letter_grade){
        this.term_id = term_id;
        this.course_id = course_id;
        this.student_id = student_id;
        this.exams_score = exams_score;
        this.others_score = others_score;
        this.total_score = total_score;
        this.letter_grade = letter_grade;
    }

    public void setScores(double new_exams_score, double new_others_score, boolean withdrew){
        if (new_exams_score < 0.0 || new_exams_score > 100.0){
            throw new RuntimeException("Invalid new value for Exams Score");
        }
        if (new_others_score < 0.0 || new_others_score > 100.0){
            throw new RuntimeException("Invalid new value for Others Score");
        }
        if (new_exams_score + new_others_score > 100.0){
            throw new RuntimeException("Total new score cannot go over 100");
        }
        this.exams_score = new_exams_score;
        this.others_score = new_others_score;
        this.total_score = this.exams_score + this.others_score;

        if (withdrew){
            this.letter_grade = "W";
        } else {
            if (this.total_score > 0.90){
                this.letter_grade = "A";
            } else {
                if (this.total_score > 0.80){
                    this.letter_grade = "B";
                } else {
                    if (this.total_score > 0.70){
                        this.letter_grade = "C";
                    } else {
                        if (this.total_score >= 0.60){
                            this.letter_grade = "D";
                        } else {
                            this.letter_grade = "F";
                        }
                    }
                }
            }
        }
    }

    public double getExamsScore(){
        return this.exams_score;
    }

    public double getOthersScore(){
        return this.others_score;
    }

    public double getTotalScore(){
        return this.total_score;
    }

    public String getLetterGrade(){
        return this.letter_grade;
    }

    public String getKey(){
        return this.term_id + "-" + this.course_id + "-" + this.student_id;
    }
}
